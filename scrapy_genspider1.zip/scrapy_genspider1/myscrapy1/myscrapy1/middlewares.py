# Define here the models for your spider middleware
#
# See documentation in:
# https://docs.scrapy.org/en/latest/topics/spider-middleware.html

from scrapy import signals
from scrapy.http.headers import Headers
from myscrapy1 import user_agent
import urllib.request as ur
# useful for handling different item types with a single interface
from itemadapter import is_item, ItemAdapter


class Myscrapy1SpiderMiddleware:
    # Not all methods need to be defined. If a method is not defined,
    # scrapy acts as if the spider middleware does not modify the
    # passed objects.

    @classmethod
    def from_crawler(cls, crawler):
        # This method is used by Scrapy to create your spiders.
        s = cls()
        crawler.signals.connect(s.spider_opened, signal=signals.spider_opened)
        return s

    def process_spider_input(self, response, spider):
        # Called for each response that goes through the spider
        # middleware and into the spider.

        # Should return None or raise an exception.
        return None

    def process_spider_output(self, response, result, spider):
        # Called with the results returned from the Spider, after
        # it has processed the response.

        # Must return an iterable of Request, or item objects.
        for i in result:
            yield i

    def process_spider_exception(self, response, exception, spider):
        # Called when a spider or process_spider_input() method
        # (from other spider middleware) raises an exception.

        # Should return either None or an iterable of Request or item objects.
        pass

    def process_start_requests(self, start_requests, spider):
        # Called with the start requests of the spider, and works
        # similarly to the process_spider_output() method, except
        # that it doesn’t have a response associated.

        # Must return only requests (not items).
        for r in start_requests:
            yield r

    def spider_opened(self, spider):
        spider.logger.info('Spider opened: %s' % spider.name)


class Myscrapy1DownloaderMiddleware:
    # Not all methods need to be defined. If a method is not defined,
    # scrapy acts as if the downloader middleware does not modify the
    # passed objects.

    @classmethod
    def from_crawler(cls, crawler):
        # This method is used by Scrapy to create your spiders.
        s = cls()
        crawler.signals.connect(s.spider_opened, signal=signals.spider_opened)
        return s

    def process_request(self, request, spider):
        # 添加请求头和代理 IP
        request.headers = Headers(
            {
                'user-Agent': user_agent.get_user_agent_pc(),
                'Cookie':'uuid_tt_dd=10_10351383310-1597660145281-809420; dc_session_id=10_1597660145281.154708; UN=weixin_44549563; announcement=%257B%2522isLogin%2522%253Atrue%252C%2522announcementUrl%2522%253A%2522https%253A%252F%252Flive.csdn.net%252Froom%252Fyzkskaka%252Fats4dBdZ%253Futm_source%253D908346557%2522%252C%2522announcementCount%2522%253A0%257D; Hm_ct_6bcd52f51e9b3dce32bec4a3997715ac=6525*1*10_10351383310-1597660145281-809420!5744*1*weixin_44549563; p_uid=U110000; Hm_up_facf15707d34a73694bf5c0d571a4a72=%7B%22islogin%22%3A%7B%22value%22%3A%221%22%2C%22scope%22%3A1%7D%2C%22isonline%22%3A%7B%22value%22%3A%221%22%2C%22scope%22%3A1%7D%2C%22isvip%22%3A%7B%22value%22%3A%221%22%2C%22scope%22%3A1%7D%2C%22uid_%22%3A%7B%22value%22%3A%22weixin_44549563%22%2C%22scope%22%3A1%7D%7D; Hm_ct_facf15707d34a73694bf5c0d571a4a72=6525*1*10_10351383310-1597660145281-809420!5744*1*weixin_44549563; Hm_lvt_facf15707d34a73694bf5c0d571a4a72=1598581707,1598581891; Hm_lvt_146e5663e755281a5bbe1f3f1c477685=1598584621; Hm_up_146e5663e755281a5bbe1f3f1c477685=%7B%22islogin%22%3A%7B%22value%22%3A%221%22%2C%22scope%22%3A1%7D%2C%22isonline%22%3A%7B%22value%22%3A%221%22%2C%22scope%22%3A1%7D%2C%22isvip%22%3A%7B%22value%22%3A%221%22%2C%22scope%22%3A1%7D%2C%22uid_%22%3A%7B%22value%22%3A%22weixin_44549563%22%2C%22scope%22%3A1%7D%7D; Hm_ct_146e5663e755281a5bbe1f3f1c477685=5744*1*weixin_44549563!6525*1*10_10351383310-1597660145281-809420; UserName=weixin_44549563; UserInfo=e51e6feb0607444785ed5cea90bf6374; UserToken=e51e6feb0607444785ed5cea90bf6374; UserNick=%E3%81%A5%E5%AE%89%E7%9C%A0%E4%B8%B6%E4%B9%90%E7%81%AC; AU=612; BT=1598598251970; searchHistoryArray=%255B%2522python%2522%252C%2522java%2522%255D; log_Id_view=106; log_Id_click=14; log_Id_pv=40; Hm_up_6bcd52f51e9b3dce32bec4a3997715ac=%7B%22uid_%22%3A%7B%22value%22%3A%22weixin_44549563%22%2C%22scope%22%3A1%7D%2C%22islogin%22%3A%7B%22value%22%3A%221%22%2C%22scope%22%3A1%7D%2C%22isonline%22%3A%7B%22value%22%3A%221%22%2C%22scope%22%3A1%7D%2C%22isvip%22%3A%7B%22value%22%3A%221%22%2C%22scope%22%3A1%7D%7D; dc_sid=2da63cd6055b60a5d249927b7341abd3; TY_SESSION_ID=80313a5e-21cc-4b8a-a3e3-9a35649e6b52; c_first_ref=default; c_first_page=https%3A//blog.csdn.net/; dc_tos=qgr801; Hm_lvt_6bcd52f51e9b3dce32bec4a3997715ac=1599659446,1599659544,1599662036,1600264514; Hm_lpvt_6bcd52f51e9b3dce32bec4a3997715ac=1600264514; Hm_lvt_eaa57ca47dacb4ad4f5a257001a3457c=1600264520; Hm_lpvt_eaa57ca47dacb4ad4f5a257001a3457c=1600264520'
            }
        )
        # 使用代理 IP
        request.meta['proxy'] = 'http://' + ur.urlopen('http://api.ip.data5u.com/dynamic/get.html?order=465ff3e1663984d252af0e2cfd496959&random=1&sep=3').read().decode('utf-8').strip()
        # print('*'*100)

        # Called for each request that goes through the downloader
        # middleware.

        # Must either:
        # - return None: continue processing this request
        # - or return a Response object
        # - or return a Request object
        # - or raise IgnoreRequest: process_exception() methods of
        #   installed downloader middleware will be called
        return None

    def process_response(self, request, response, spider):
        # Called with the response returned from the downloader.

        # Must either;
        # - return a Response object
        # - return a Request object
        # - or raise IgnoreRequest
        return response

    def process_exception(self, request, exception, spider):

        # Called when a download handler or a process_request()
        # (from other downloader middleware) raises an exception.

        # Must either:
        # - return None: continue processing this exception
        # - return a Response object: stops process_exception() chain
        # - return a Request object: stops process_exception() chain
        pass

    def spider_opened(self, spider):
        spider.logger.info('Spider opened: %s' % spider.name)
