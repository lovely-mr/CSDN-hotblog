import re

import scrapy

class CsdnBlogSpider(scrapy.Spider):
    name = 'csdn_blog'
    allowed_domains = ['blog.csdn.net']
    keyword = 'python'

    def start_requests(self):
        for pn in range(1,11):
            url = 'https://blog.csdn.net/'
            yield scrapy.Request(
                url = url,
                callback = self.parse
            )
    # start_urls = ['http://blog.scdn.net/']
    def parse(self,response):
        href_s = response.xpath("//ul[@id='feedlist_id']//li/div[1]//div[1]/h2/a/@href").extract()
        print(href_s)
        for href in href_s:
            yield scrapy.Request(
                url=href,
                callback=self.parse2
            )

    def parse2(self,response):
        item = dict(
            title=response.xpath('//h1[@class="title-article"]/text()').extract_first(),
            data=response.body
        )
        if item['title']:
            title = re.sub(
                r'[/\\:*"<>|?]', '', item['title']
            )
            filepath = 'blog_html/{title}.html'.format(title=title)
            with open(filepath, 'wb', ) as f:
                f.write(item['data'])
                print(title)
        yield item