import scrapy


class S1Spider(scrapy.Spider):
    name = 's1'
    allowed_domains = ['hao123.com/book']
    start_urls = ['http://www.hao123.com/book']

    # def parse(self, response):
    #     print('-'*30)
    #     print(response.xpath('//div[@class="nav_com"]/ul/li/a/text()').extract())
    #     print('-' * 30)

    def start_requests(self):
        yield scrapy.Request(
            url='http://www.hao123.com/book',
            callback=self.parse2
        )
    def parse2(self,response):
        # print('-' * 30)
        print(response.xpath('//div[@class="content-con content-con-first"]/ul/li/h3//a/text()').extract())
        data = response.xpath('//div[@class="content-con content-con-first"]/ul/li/h3//a/text()').extract()
        item ={}
        item['data']=data
        yield item   # 如果 yield 是一个 request 对象，就会把对象交给 schedule
                     # 如果 yield 是一个字典对象，就会把对象交给管道文件
        # print('-' * 30)
