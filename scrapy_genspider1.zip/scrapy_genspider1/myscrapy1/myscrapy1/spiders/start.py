from scrapy import cmdline

cmdline.execute('scrapy crawl csdn_blog'.split())